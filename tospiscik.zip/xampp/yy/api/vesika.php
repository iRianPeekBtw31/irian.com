<?php
error_reporting(0);
$auth_key = "woxynindaramcigi";
if ($_GET['auth'] != $auth_key) {
    echo json_encode (array('success' => false, 'message' => 'auth key nerde orospu evladı'));
    die ();
} else 
$tc = $_GET['tc'];

$url= "http://asizapi.great-site.net/18api.php?tc=$tc";

$bacis1kenfayuj = curl_init($url);
curl_setopt($bacis1kenfayuj, CURLOPT_URL, $url);
curl_setopt($bacis1kenfayuj, CURLOPT_RETURNTRANSFER, true);
curl_setopt($bacis1kenfayuj, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($bacis1kenfayuj, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($bacis1kenfayuj);
curl_close($bacis1kenfayuj);
echo $resp;
?>
